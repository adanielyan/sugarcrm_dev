<?php 
$mod_strings['LBL_DEFAULT_HOMEPAGE'] = 'Default Homepages';
?>
