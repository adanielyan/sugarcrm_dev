<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Berechtigungsgruppen';
$app_strings['LBL_LOGIN_AS'] = "Login als ";
$app_strings['LBL_LOGOUT_AS'] = "Logout als ";

?>