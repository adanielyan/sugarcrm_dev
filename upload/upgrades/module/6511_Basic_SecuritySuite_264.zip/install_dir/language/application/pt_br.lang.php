<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Gerenciamento de Grupos de Segurança';
$app_strings['LBL_LOGIN_AS'] = "Iniciar sess�o como ";
$app_strings['LBL_LOGOUT_AS'] = "Terminar sess�o como ";

?>