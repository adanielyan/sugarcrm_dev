<?php

$mod_strings['LBL_DEFAULT'] = 'Alapértelmezett';
$mod_strings['LBL_ADD_LAYOUT'] = 'Elrendezés Hozzáadása';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Elrendezés Hozzáadása';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Válasszon Csoport Elrendezést a hozzáadáshoz.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Csoport Elrendezés Eltávolítása';

$mod_strings['LBL_SECURITYGROUP'] = 'Biztonsági Csoport:';
$mod_strings['LBL_COPY_FROM'] = 'Másolás Ebből:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Elrendezés Mentve';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Elrendezés Eltávolítva';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Valóban eltávolítja?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Biztonsági Csoport egyedi elrendezésének készítéséhez válassza ki a megfelelő csoportot és az elrendezést melyet kiindulásként használ a másoláskor.";

?>
