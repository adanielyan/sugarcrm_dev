<?php

$mod_strings['LBL_DEFAULT'] = 'R�ckstellung';
$mod_strings['LBL_ADD_LAYOUT'] = 'Addieren Sie Plan';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Addieren Sie Plan';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'W�hlen Sie einen Gruppen-Plan vor, um hinzuzuf�gen.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Entfernen Sie Gruppen-Plan';

$mod_strings['LBL_SECURITYGROUP'] = 'Berechtigungsgruppe:';
$mod_strings['LBL_COPY_FROM'] = 'Kopieren Sie von:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Plan speicherte';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'Plan entfernte';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Sind Sie wirklich sicher?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Um einen kundenspezifischen Plan f�r ein Berechtigungsgruppe zu verursachen w�hlen Sie das passende Berechtigungsgruppe und den Plan vor von denen zur Kopie von als Ausgangspunkt.";

?>
