<?php

$mod_strings['LBL_DEFAULT'] = 'По замовчуванню';
$mod_strings['LBL_ADD_LAYOUT'] = 'Додати макет';
$mod_strings['LBL_ADD_LAYOUTS'] = 'Додати макети';
$mod_strings['LBL_QUESTION_ADD_LAYOUT'] = 'Виберіть макет Групи для додавання.';
$mod_strings['LBL_REMOVE_LAYOUT'] = 'Видалити макет Групи';

$mod_strings['LBL_SECURITYGROUP'] = 'Групи користувачів:';
$mod_strings['LBL_COPY_FROM'] = 'Копіювати з:';
$mod_strings['LBL_ADDLAYOUTDONE'] = 'Збереженний макет';
$mod_strings['LBL_REMOVELAYOUTDONE'] = 'видалений макет';
$mod_strings['LBL_REMOVE_CONFIRM'] = 'Ви дійсно впевнені?';
$mod_strings['help']['studioWizard']['addLayoutHelp'] = "Для створення макету Групи користувачів виберіть відповідну Групу і макет для копіювання.";

?>
