<?php

$mod_strings = array_merge($mod_strings,
	array(
  		'LBL_ACCESS_GROUP' => 'Csoport',
	)
);
?>
