<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_LIST_NONINHERITABLE' => 'Не успадковується',
	)
);
?>
