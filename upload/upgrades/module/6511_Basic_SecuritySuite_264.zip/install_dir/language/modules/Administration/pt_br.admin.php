<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Gerenciamento do Módulo de Grupos de Segurança';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Editor do Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Configurações do Módulo de Grupos de Segurança';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Configurações do Gerenciador do Módulo de Grupos de Segurança como herança, aditivo de segurança, etc';
$mod_strings['LBL_SECURITYGROUPS'] = 'Módulo de Grupos de Segurança';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = "Melhoramento e Informação Geral";
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = "Informação Grupos de Segurança";
$mod_strings['LBL_SECURITYGROUPS_INFO'] = "Informação Geral";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = "Empurre a mensagem Dashlet";
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = "Push the Message Dashlet to the Home page for all users. This process may take some time to complete depending on the number of users";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = "Módulo da conexão";
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = "Série da Grupos de Segurança a trabalhar com seus módulos feitos sob encomenda";

?>
