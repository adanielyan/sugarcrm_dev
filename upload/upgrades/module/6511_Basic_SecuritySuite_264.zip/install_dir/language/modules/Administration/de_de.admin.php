<?php

$mod_strings['LBL_MANAGE_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen';
$mod_strings['LBL_MANAGE_SECURITYGROUPS'] = 'Erstellen und verwalten von Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS_TITLE'] = 'Berechtigungsgruppen - Einstellungen';
$mod_strings['LBL_CONFIG_SECURITYGROUPS'] = 'Passen Sie die Parameter für Berechtigungsgruppen an';
$mod_strings['LBL_SECURITYGROUPS'] = 'Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS_UPGRADE_INFO_TITLE'] = 'Aktualisierung und generelle Informationen';
$mod_strings['LBL_SECURITYGROUPS_INFO_TITLE'] = 'Info Berechtigungsgruppen';
$mod_strings['LBL_SECURITYGROUPS_INFO'] = 'Generelle Informationen';
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH_TITLE'] = 'Nachrichtendashlet verteilen';
$mod_strings['LBL_SECURITYGROUPS_DASHLETPUSH'] = 'Verteilen Sie das Nachrichtendashlet an alle Benutzer. Abhängig von der Anzahl kann dieser Vorgang einige Zeit in Anspruch nehmen';
$mod_strings['LBL_SECURITYGROUPS_HOOKUP_TITLE'] = 'Module verbinden';
$mod_strings['LBL_SECURITYGROUPS_HOOKUP'] = 'Verbinden Sie Berechtigungsgruppen mit Ihren selbst erstellten Modulen';


?>
