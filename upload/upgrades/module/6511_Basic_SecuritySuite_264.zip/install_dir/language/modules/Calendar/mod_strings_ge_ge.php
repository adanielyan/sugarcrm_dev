<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Filterbenutzerliste durch Berechtigungsgruppen';
?>