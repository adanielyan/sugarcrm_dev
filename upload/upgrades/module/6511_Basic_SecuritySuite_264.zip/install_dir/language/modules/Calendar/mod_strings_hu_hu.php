<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Felhasználók Listájának szűrése Biztonsági Csoport szerint';
?>
