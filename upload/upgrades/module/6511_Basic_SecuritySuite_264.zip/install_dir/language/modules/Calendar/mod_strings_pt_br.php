<?php

$mod_strings['LBL_SECURITYGROUPS'] = 'Lista de usu�rio do filtro pelo Grupos de Seguran�a';
?>