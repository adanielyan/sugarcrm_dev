<?php

$dictionary['securitygroups_opportunites'] = array ( ); 

?>
