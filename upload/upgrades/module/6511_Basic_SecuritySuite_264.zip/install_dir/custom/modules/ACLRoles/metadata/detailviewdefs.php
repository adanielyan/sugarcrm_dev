<?php
$viewdefs['ACLRoles']['DetailView'] = array(
    'templateMeta' => array('form' => array(),
                            'maxColumns' => '', 
                            'widths' => array(
                                            ),
                            'includes'=> array(
                                         ),                                            
                           ),
    'panels' => array(
	      
     ),
    
    
);
?>
