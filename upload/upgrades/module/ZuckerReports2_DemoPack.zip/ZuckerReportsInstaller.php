<?php

function zr_log($str) {
	echo "ZuckerReportsInstaller: ".$str."<br/>";
}

function post_install( ) {
	zr_log("post_install() started.");

	global $reportdefs;
	if (!empty($reportdefs)) { run_report_installer($reportdefs); }

	zr_log("post_install() finished.");
}

function run_report_installer($reportdefs) {
	if (is_file('modules/zr2_ReportTemplate/zr2_ReportTemplate.php')) {
		require_once('modules/zr2_ReportTemplate/zr2_ReportTemplate.php');
		require_once('modules/zr2_ReportParameter/zr2_ReportParameter.php');
		require_once('modules/zr2_ReportParameterLink/zr2_ReportParameterLink.php');
		
		foreach ($reportdefs as $reportdef) {
		
			$filename_base = $reportdef["filename_base"];
			$subreports_base = $reportdef["subreports_base"];
			$resources = $reportdef["resources"];
			$report_name = $reportdef["report_name"];
			$report_description = $reportdef["report_description"];
			$report_export_as = $reportdef["report_export_as"];
			$report_params = $reportdef["report_params"];
			if (empty($subreports_base)) $subreports_base = array();
			if (empty($resources)) $resources = array();
			if (empty($report_params)) $report_params = array();
			
			$seed = zr2_ReportTemplate::getByFilename($filename_base.".jasper");
			
			if (!$seed) {
				zr_log("run_report_installer() installing ".$report_name." ... ");
			
				$seed = new zr2_ReportTemplate();
				$seed->id = create_guid();
				$seed->new_with_id = true;
				$seed->name = $report_name;
				$seed->description = $report_description;
				$seed->export_as = $report_export_as;
		
				$success = $seed->set_reportfile("cache/upload/".$filename_base.".jrxml", $filename_base.".jrxml");
				if (!$success) {
					echo $seed->report_output;
					return;
				}
				foreach ($subreports_base as $sub) {
					$success = $seed->add_subreportfile("cache/upload/".$sub.".jrxml", $sub.".jrxml");
					if (!$success) {
						echo $seed->report_output;
						return;
					}
				}
				foreach ($resources as $res) {
					$success = $seed->add_resource_file("cache/upload/".$res, $res);
					if (!$success) {
						echo $seed->report_output;
						return;
					}
				}
				
				$seed->save();
				
				foreach ($report_params as $report_param) {
					$pseed = zr2_ReportParameter::getByDefaultname($report_param["default_name"]);
					if (!$pseed) {
						$pseed = new zr2_ReportParameter();
						$pseed->name = $report_param["friendly_name"];
						$pseed->friendly_name = $report_param["friendly_name"];
						$pseed->default_name = $report_param["default_name"];
						$pseed->default_value = $report_param["default_value"];
						$pseed->description = $report_param["description"];
						$pseed->range_name = (empty($report_param["range"]) ? "SIMPLE" : $report_param["range"]);
						$pseed->range_options = $report_param["range_options"];
						$pseed->save();
					}
					
					$lseed = new zr2_ReportParameterLink();
					$lseed->name = $report_param["default_name"];
					$lseed->default_value = $report_param["default_value"];
					$lseed->save();
					
					$lseed->load_relationship("zr2_reportparameterlink_zr2_reportparameter");
					$lseed->zr2_reportparameterlink_zr2_reportparameter->add($pseed->id);

					$lseed->load_relationship("zr2_reportparameterlink_zr2_reporttemplate");
					$lseed->zr2_reportparameterlink_zr2_reporttemplate->add($seed->id);
				}
				zr_log("run_report_installer() installing ".$report_name." ready.");
			} else {
				zr_log("run_report_installer() report ".$report_name." already present.");
			}
		}
	}
}



?>