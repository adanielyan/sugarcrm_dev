<?php

global $reportdefs;
$reportdefs = array(
	array(
		"filename_base" => "Activity",
		"subreports_base" => array("ClosedOpportunitiesSubreport", "LostOpportunitiesSubreport", "NewOpportunitiesSubreport"),
		"resources" => array(),
		"report_name" => "Activity",
		"report_description" => "This report lists all activity",
		"report_export_as" => "PDF XLS HTML",
		"report_params" => array(
				array(
					"friendly_name" => "Range (days)",
					"default_name" => "range_days",
					"default_value" => "7",
					"description" => "Number of days to include",
					"range" => "SIMPLE",
					"range_options" => "",
				),
			),
	),
	array(
		"filename_base" => "ClosedDeals",
		"report_name" => "Closed Deals",
		"report_description" => "This report lists all closed deals by user",
		"report_export_as" => "PDF XLS HTML",
		"report_params" => array(
				array(
					"friendly_name" => "First Name",
					"default_name" => "firstName",
					"default_value" => "",
					"description" => "First Name",
					"range" => "SIMPLE",
					"range_options" => "",
				),
				array(
					"friendly_name" => "Last Name",
					"default_name" => "lastName",
					"default_value" => "",
					"description" => "Last Name",
					"range" => "SIMPLE",
					"range_options" => "",
				),
			),
	),
	array(
		"filename_base" => "MeetingPrintout",
		"subreports_base" => array("MeetingPrintout_Contacts", "MeetingPrintout_Users"),
		"resources" => array("logo.gif"),
		"report_name" => "Meeting Printout",
		"report_description" => "This report prints meeting details",
		"report_export_as" => "PDF XLS HTML",
		"report_params" => array(
				array(
					"friendly_name" => "Meeting",
					"default_name" => "MEETING_ID",
					"default_value" => "",
					"description" => "Meeting Selection Box",
					"range" => "SQL",
					"range_options" => 'select id, concat(name, " (", date_start, ")") from meetings where deleted = 0 order by name, date_start',
				),
			),
	),
	array(
		"filename_base" => "Opportunities",
		"report_name" => "Opportunities",
		"report_description" => "This report lists all opportunities",
		"report_export_as" => "PDF XLS HTML",
	),
	array(
		"filename_base" => "OpportunitiesByIndustry",
		"report_name" => "Opportunities By Industry",
		"report_description" => "This report lists all opportunities by industry",
		"report_export_as" => "PDF XLS HTML",
	),
	array(
		"filename_base" => "OpportunityHistoryDetail",
		"report_name" => "Opportunity History Detail",
		"report_description" => "This report lists all opportunity history details",
		"report_export_as" => "PDF XLS HTML",
		"report_params" => array(
				array(
					"friendly_name" => "Range (days)",
					"default_name" => "range_days",
					"default_value" => "7",
					"description" => "Number of days to include",
					"range" => "SIMPLE",
					"range_options" => "",
				),
			),
	),
	array(
		"filename_base" => "PipelineBySalesStageChart",
		"report_name" => "Pipeline By Sales Stage (Chart)",
		"report_description" => "Shows a chart with the sales pipeline, grouped by stage",
		"report_export_as" => "PDF XLS HTML",
	),
);
require_once("cache/upgrades/temp/" . $_REQUEST['unzip_dir'] . "/ZuckerReportsInstaller.php");

?>
