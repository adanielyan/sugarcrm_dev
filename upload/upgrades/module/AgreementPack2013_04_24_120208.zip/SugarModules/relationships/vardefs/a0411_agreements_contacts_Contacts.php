<?php
// created: 2013-04-11 10:28:00
$dictionary["Contact"]["fields"]["a0411_agreements_contacts"] = array (
  'name' => 'a0411_agreements_contacts',
  'type' => 'link',
  'relationship' => 'a0411_agreements_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_A0411_AGREEMENTS_CONTACTS_FROM_A0411_AGREEMENTS_TITLE',
);
