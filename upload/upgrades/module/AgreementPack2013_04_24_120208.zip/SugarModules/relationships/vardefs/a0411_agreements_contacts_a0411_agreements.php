<?php
// created: 2013-04-11 10:28:00
$dictionary["a0411_agreements"]["fields"]["a0411_agreements_contacts"] = array (
  'name' => 'a0411_agreements_contacts',
  'type' => 'link',
  'relationship' => 'a0411_agreements_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_A0411_AGREEMENTS_CONTACTS_FROM_CONTACTS_TITLE',
);
