<?php
// created: 2013-04-11 10:28:00
$dictionary["Account"]["fields"]["a0411_agreements_accounts"] = array (
  'name' => 'a0411_agreements_accounts',
  'type' => 'link',
  'relationship' => 'a0411_agreements_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_A0411_AGREEMENTS_ACCOUNTS_FROM_A0411_AGREEMENTS_TITLE',
);
