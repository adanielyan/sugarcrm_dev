<?PHP
$app_strings['LBL_FORMROUTER_BUTTON'] = array(
		    'LBL_PDFBUTTON' => 'Button Text',
		    'LBL_PDFBUTTON_DEF_TEXT' => 'Get PDF',
                'LBL_PDFURL' => 'ID to Use in Sugar',
                'LBL_PDFURL_INFO' => 'The ID from your PDFforSugar.com account for the file you want to pre-populate (enter TEST here to find out the names of the fields in this Module)',
		    'LBL_ONLY_IN_STUDIO' => 'Only available in Sugar Studio (deploy then edit in Studio)',
        );
?>
