<?PHP
$mod_strings['fieldTypes']['FRPDFButton'] = 'PDF for Sugar Button';
?>
