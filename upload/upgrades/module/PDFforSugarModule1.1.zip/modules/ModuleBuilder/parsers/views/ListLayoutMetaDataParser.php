                if (isset ( $this->_fielddefs [ $fieldname ] ) && (isset($this->_fielddefs[$fieldname]['type']))
                        && $this->_fielddefs [ $fieldname ] [ 'type' ] == 'FRPDFButton' && ($this->_fielddefs [ $fieldname ]['source'] == 'non-db' || $this->_fielddefs [ $fieldname ]['dbtype'] == 'text'))
                {
                    $newViewdefs [ $fieldname ] [ 'sortable' ] = false ;
                }
