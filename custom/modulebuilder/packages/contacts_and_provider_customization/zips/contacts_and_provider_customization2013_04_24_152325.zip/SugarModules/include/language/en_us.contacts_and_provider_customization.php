<?php 
$app_list_strings['account_status_list'] = array (
  'Applicant' => 'Applicant',
  'Provider' => 'Provider',
);