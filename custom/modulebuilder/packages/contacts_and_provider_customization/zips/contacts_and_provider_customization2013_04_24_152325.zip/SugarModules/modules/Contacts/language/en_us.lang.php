<?php 
 // created: 2013-04-24 15:23:24
$mod_strings['LBL_ACCOUNT_NAME'] = 'Provider Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Provider ID:';
$mod_strings['LBL_ACCOUNT'] = 'Provider';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Provider Name';
$mod_strings['LBL_A0411_AGREEMENTS_CONTACTS_2_FROM_A0411_AGREEMENTS_TITLE'] = 'Assigned as RELO for Agreements:';
$mod_strings['LBL_A0411_AGREEMENTS_CONTACTS_3_FROM_A0411_AGREEMENTS_TITLE'] = 'Assigned as a Post Contact for Agreements';
$mod_strings['LBL_A0411_AGREEMENTS_CONTACTS_1_FROM_A0411_AGREEMENTS_TITLE'] = 'Assigned as ECA for Agreements';
$mod_strings['LBL_CONTACTS_A0411_AGREEMENTS_2_FROM_A0411_AGREEMENTS_TITLE'] = 'Assigned as Provider Signatory Contact for Agreements';
$mod_strings['LBL_CONTACTS_A0411_AGREEMENTS_1_FROM_A0411_AGREEMENTS_TITLE'] = 'Assigned as Post Signatory Contact for Agreements';
$mod_strings['LBL_PRIMARY_CONTACT'] = 'Primary';

?>
