<?php 
 // created: 2013-08-16 11:37:31
$mod_strings['LBL_ACCOUNT_STATUS'] = 'Status';
$mod_strings['LNK_NEW_ACCOUNT'] = 'Create Provider';
$mod_strings['LNK_ACCOUNT_LIST'] = 'View Providers';
$mod_strings['LNK_IMPORT_ACCOUNTS'] = 'Import Providers';
$mod_strings['MSG_SHOW_DUPLICATES'] = 'The provider record you are about to create might be a duplicate of an provider record that already exists. Provider records containing similar names are listed below.Click Save to continue creating this new provider, or click Cancel to return to the module without creating the provider.';
$mod_strings['LBL_SAVE_ACCOUNT'] = 'Save Provider';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Provider List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Provider Search';
$mod_strings['LBL_MEMBER_OF'] = 'Member of:';
$mod_strings['LBL_MEMBERS'] = 'Members';
$mod_strings['LBL_MEMBER_ORG_SUBPANEL_TITLE'] = 'Member Organizations';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Providers';
$mod_strings['LBL_PARENT_ACCOUNT_ID'] = 'Parent Provider ID';
$mod_strings['LBL_MODULE_NAME'] = 'Providers';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Provider Name';
$mod_strings['LBL_NAME'] = 'Provider Name';
$mod_strings['LBL_WEBSITE'] = 'Provider Website';
$mod_strings['LBL_REGION'] = 'Region';
$mod_strings['LBL_COUNTRY'] = 'Country';
$mod_strings['LBL_TASK_NAME'] = 'Task Name';
$mod_strings['LBL_PROVIDER_ADDRESS'] = 'Provider Address';
$mod_strings['LBL_PROVIDER_CITY'] = 'Provider_City';
$mod_strings['LBL_PROVIDER_STATE_PROVINCE_REGI'] = 'Provider State/Province/Region';
$mod_strings['LBL_PROVIDER_ZIP_CODE'] = 'Provider Zip/Postal Code';
$mod_strings['LBL_PROVIDER_WEB_SITE'] = 'Provider Website';
$mod_strings['LBL_DUNS'] = 'DUNS';
$mod_strings['LBL_PAR_DUNS'] = 'Parent DUNS';

?>
