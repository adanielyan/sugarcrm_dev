<?php
$module_name = 'bank_Agreements';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'task_number',
            'label' => 'LBL_TASK_NUMBER',
          ),
          1 => 
          array (
            'name' => 'prop_aproved_date',
            'label' => 'LBL_PROP_APROVED_DATE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'agreement_number',
            'label' => 'LBL_AGREEMENT_NUMBER',
          ),
          1 => 
          array (
            'name' => 'agreement_date',
            'label' => 'LBL_AGREEMENT_DATE',
          ),
        ),
        3 => 
        array (
          0 => 'description',
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'bank_agreements_accounts_name',
          ),
        ),
      ),
    ),
  ),
);
?>
