<?php 
 // created: 2013-05-03 23:01:49
$mod_strings['LBL_CUSTOM_TEST_FIELD'] = 'custom test field';

?>
